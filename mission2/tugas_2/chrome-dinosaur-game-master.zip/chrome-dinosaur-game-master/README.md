# [Chrome Dinosaur Game](https://youtu.be/lgck-txzp9o)
- Coding Tutorial: https://youtu.be/lgck-txzp9o
- Demo: https://imkennyyip.github.io/chrome-dinosaur-game/

In this tutorial, you will learn how to create the famous google chrome dinosaur game! You will learn how to create this game using html canvas. Throughout the tutorial, you will learn how to create the game loop, add images onto the canvas, add click handlers to allow the dinosaur to jump, randomly generate cactuses or cacti and move them across the screen, detect collisions betwee the dinosaur and each cactus, and add a running score.

![chrome-dino-sample](https://user-images.githubusercontent.com/78777681/211173895-312de010-59fa-440b-bd76-d75b99feaa78.png)
